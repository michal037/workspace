#include <iostream>

using namespace std;

int main() {
	cout << "Hello World!" << endl;

	int a = 0;
	while(a < 3) {
		cout << "value: " << a << endl;
		a++;
	}

	return 0;
}